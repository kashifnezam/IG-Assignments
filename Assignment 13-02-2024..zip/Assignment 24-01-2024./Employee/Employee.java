import java.util.ArrayList;
import java.util.List;

public class Employee extends Person {
    private List<Salary> salaries;
    private int monthJoined;
    private int year;
    private String company;

    public Employee(int id, String name, int monthJoined, int year, String company) {
        super(id, name);
        this.monthJoined = monthJoined;
        this.year = year;
        this.company = company;
        this.salaries = new ArrayList<>();
    }

    public int getMonthJoined() {
        return monthJoined;
    }

    public int getYear() {
        return year;
    }

    public String getCompany() {
        return company;
    }

    public List<Salary> getSalaries() {
        return salaries;
    }

    public void addSalary(Salary salary) {
        salaries.add(salary);
    }

    public Double calculateTotalSalary() {
//        int sum = 0;
//        for (Salary s : salaries) {
//            sum += s.getSalary();
//        }

        return salaries.stream().map(Salary::getSalary).reduce(Double::sum).get();
    }

    @Override
    public String toString() {
        return "[" + getId() + " _ " + getName() + " _ " + calculateTotalSalary() + " _ " + getCompany() + "]";
    }
}
