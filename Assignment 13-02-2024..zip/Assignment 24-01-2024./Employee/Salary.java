public class Salary {
    private final int id;
    private double salary;
    private final int month;
    private final int year;

    public Salary(int id, int salary, int month, int year) {
        this.id = id;
        this.salary = salary;
        this.month = month;
        this.year = year;
    }

    public int getId() {
        return id;
    }

    public double getSalary() {
        return salary;
    }

    public int getMonth() {
        return month;
    }

    public int getYear() {
        return year;
    }

    public void setSalary(double growth){
        this.salary = salary*growth;
    }


    @Override
    public String toString(){
        return id+" _ "+salary+" _ "+month+" _ "+year;
    }

}
