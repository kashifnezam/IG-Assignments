import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;


public class Main {

    public static void main(String[] args) {

//        Employee Creation
//        String [] com = {"InsightGeeks", "Samsung", "Apple"};
//        for (int i = 1; i <= 10; i++) {
//            String companyName = (com[i % 3]); // Three dummy company names
//            Employee employee = new Employee(i, "Employee " + i, 1, 2023, companyName);
//            for (int j = 1; j <= 12; j++) {
//                // Add dummy salaries for the last 12 months
//                employee.addSalary(new Salary((i * 100) + j, 5000 + (i * 100) + j, j, 2023)); // Assuming salary increases each month
//            }
//            employees.add(employee);
//        }

//      -----------------  Employee Object      -----------------
        Employee emp1 = new Employee(1, "Kashif", 1, 2022, "InsightGeeks");
        Employee emp2 = new Employee(2, "John", 2, 2023, "TechSolutions");
        Employee emp3 = new Employee(3, "Emily", 3, 2020, "DataExperts");
        Employee emp4 = new Employee(4, "Michael", 4, 2021, "InsightGeeks");
        Employee emp5 = new Employee(5, "Sarah", 5, 2019, "DataExperts");
        Employee emp6 = new Employee(6, "David", 6, 2018, "InsightGeeks");
        Employee emp7 = new Employee(7, "Jennifer", 7, 2020, "TechSolutions");
        Employee emp8 = new Employee(8, "Ryan", 8, 2024, "DataExperts");
        Employee emp9 = new Employee(9, "Michelle", 9, 2023, "InsightGeeks");
        Employee emp10 = new Employee(10, "Alex", 10, 2022, "TechSolutions");


//        ---------- Salary Object Added ------------
//  emp1
        emp1.addSalary(new Salary(101, 28000, 1, 2022));
        emp1.addSalary(new Salary(102, 28888, 2, 2022));
        emp1.addSalary(new Salary(103, 25050, 4, 2022));
        emp1.addSalary(new Salary(104, 30000, 5, 2022));
        emp1.addSalary(new Salary(105, 31000, 6, 2022));
        emp1.addSalary(new Salary(106, 32000, 7, 2022));
        emp1.addSalary(new Salary(107, 33000, 8, 2022));
        emp1.addSalary(new Salary(108, 34000, 9, 2022));
        emp1.addSalary(new Salary(109, 35000, 10, 2022));
        emp1.addSalary(new Salary(110, 36000, 11, 2022));
        emp1.addSalary(new Salary(111, 37000, 12, 2022));
        emp1.addSalary(new Salary(112, 38000, 1, 2023));

//Emp2
        emp2.addSalary(new Salary(201, 30000, 1, 2022));
        emp2.addSalary(new Salary(202, 31000, 2, 2022));
        emp2.addSalary(new Salary(203, 32000, 3, 2022));
        emp2.addSalary(new Salary(204, 33000, 4, 2022));
        emp2.addSalary(new Salary(205, 34000, 5, 2022));
        emp2.addSalary(new Salary(206, 35000, 6, 2022));
        emp2.addSalary(new Salary(207, 36000, 7, 2022));
        emp2.addSalary(new Salary(208, 37000, 8, 2022));
        emp2.addSalary(new Salary(209, 38000, 9, 2022));
        emp2.addSalary(new Salary(210, 39000, 10, 2022));
        emp2.addSalary(new Salary(211, 40000, 11, 2022));
        emp2.addSalary(new Salary(212, 41000, 12, 2022));

//  Emp3
        emp3.addSalary(new Salary(301, 28000, 1, 2022));
        emp3.addSalary(new Salary(302, 29000, 2, 2022));
        emp3.addSalary(new Salary(303, 30000, 3, 2022));
        emp3.addSalary(new Salary(304, 31000, 4, 2022));
        emp3.addSalary(new Salary(305, 32000, 5, 2022));
        emp3.addSalary(new Salary(306, 33000, 6, 2022));
        emp3.addSalary(new Salary(307, 34000, 7, 2022));
        emp3.addSalary(new Salary(308, 35000, 8, 2022));
        emp3.addSalary(new Salary(309, 36000, 9, 2022));
        emp3.addSalary(new Salary(310, 37000, 10, 2022));
        emp3.addSalary(new Salary(311, 38000, 11, 2022));
        emp3.addSalary(new Salary(312, 39000, 12, 2022));

//  Emp4
        emp4.addSalary(new Salary(401, 28000, 1, 2022));
        emp4.addSalary(new Salary(402, 29000, 2, 2022));
        emp4.addSalary(new Salary(403, 30000, 3, 2022));
        emp4.addSalary(new Salary(404, 31000, 4, 2022));
        emp4.addSalary(new Salary(405, 32000, 5, 2022));
        emp4.addSalary(new Salary(406, 33000, 6, 2022));
        emp4.addSalary(new Salary(407, 34000, 7, 2022));
        emp4.addSalary(new Salary(408, 35000, 8, 2022));
        emp4.addSalary(new Salary(409, 36000, 9, 2022));
        emp4.addSalary(new Salary(410, 37000, 10, 2022));
        emp4.addSalary(new Salary(411, 38000, 11, 2022));
        emp4.addSalary(new Salary(412, 39000, 12, 2022));

//Emp5
        emp5.addSalary(new Salary(501, 28000, 1, 2022));
        emp5.addSalary(new Salary(502, 29000, 2, 2022));
        emp5.addSalary(new Salary(503, 30000, 3, 2022));
        emp5.addSalary(new Salary(504, 31000, 4, 2022));
        emp5.addSalary(new Salary(505, 32000, 5, 2022));
        emp5.addSalary(new Salary(506, 33000, 6, 2022));
        emp5.addSalary(new Salary(507, 34000, 7, 2022));
        emp5.addSalary(new Salary(508, 35000, 8, 2022));
        emp5.addSalary(new Salary(509, 36000, 9, 2022));
        emp5.addSalary(new Salary(510, 37000, 10, 2022));
        emp5.addSalary(new Salary(511, 38000, 11, 2022));
        emp5.addSalary(new Salary(512, 39000, 12, 2022));

//  Emp6
        emp6.addSalary(new Salary(601, 28000, 1, 2022));
        emp6.addSalary(new Salary(602, 29000, 2, 2022));
        emp6.addSalary(new Salary(603, 30000, 3, 2022));
        emp6.addSalary(new Salary(604, 31000, 4, 2022));
        emp6.addSalary(new Salary(605, 32000, 5, 2022));
        emp6.addSalary(new Salary(606, 33000, 6, 2022));
        emp6.addSalary(new Salary(607, 34000, 7, 2022));
        emp6.addSalary(new Salary(608, 35000, 8, 2022));
        emp6.addSalary(new Salary(609, 36000, 9, 2022));
        emp6.addSalary(new Salary(610, 37000, 10, 2022));
        emp6.addSalary(new Salary(611, 38000, 11, 2022));
        emp6.addSalary(new Salary(612, 39000, 12, 2022));

//  Emp7
        emp7.addSalary(new Salary(701, 28000, 1, 2022));
        emp7.addSalary(new Salary(702, 29000, 2, 2022));
        emp7.addSalary(new Salary(703, 30000, 3, 2022));
        emp7.addSalary(new Salary(704, 31000, 4, 2022));
        emp7.addSalary(new Salary(705, 32000, 5, 2022));
        emp7.addSalary(new Salary(706, 33000, 6, 2022));
        emp7.addSalary(new Salary(707, 34000, 7, 2022));
        emp7.addSalary(new Salary(708, 35000, 8, 2022));
        emp7.addSalary(new Salary(709, 36000, 9, 2022));
        emp7.addSalary(new Salary(710, 37000, 10, 2022));
        emp7.addSalary(new Salary(711, 38000, 11, 2022));
        emp7.addSalary(new Salary(712, 39000, 12, 2022));

//  Emp8
        emp8.addSalary(new Salary(801, 28000, 1, 2022));
        emp8.addSalary(new Salary(802, 29000, 2, 2022));
        emp8.addSalary(new Salary(803, 30000, 3, 2022));
        emp8.addSalary(new Salary(804, 31000, 4, 2022));
        emp8.addSalary(new Salary(805, 32000, 5, 2022));
        emp8.addSalary(new Salary(806, 33000, 6, 2022));
        emp8.addSalary(new Salary(807, 34000, 7, 2022));
        emp8.addSalary(new Salary(808, 35000, 8, 2022));
        emp8.addSalary(new Salary(809, 36000, 9, 2022));
        emp8.addSalary(new Salary(810, 37000, 10, 2022));
        emp8.addSalary(new Salary(811, 38000, 11, 2022));
        emp8.addSalary(new Salary(812, 39000, 12, 2022));

//  Emp9
        emp9.addSalary(new Salary(901, 28000, 1, 2022));
        emp9.addSalary(new Salary(902, 29000, 2, 2022));
        emp9.addSalary(new Salary(903, 30000, 3, 2022));
        emp9.addSalary(new Salary(904, 31000, 4, 2022));
        emp9.addSalary(new Salary(905, 32000, 5, 2022));
        emp9.addSalary(new Salary(906, 33000, 6, 2022));
        emp9.addSalary(new Salary(907, 34000, 7, 2022));
        emp9.addSalary(new Salary(908, 35000, 8, 2022));
        emp9.addSalary(new Salary(909, 36000, 9, 2022));
        emp9.addSalary(new Salary(910, 37000, 10, 2022));
        emp9.addSalary(new Salary(911, 38000, 11, 2022));
        emp9.addSalary(new Salary(912, 39000, 12, 2022));

//  Emp10
        emp10.addSalary(new Salary(1001, 28000, 1, 2022));
        emp10.addSalary(new Salary(1002, 29000, 2, 2022));
        emp10.addSalary(new Salary(1003, 30000, 3, 2022));
        emp10.addSalary(new Salary(1004, 31000, 4, 2022));
        emp10.addSalary(new Salary(1005, 32000, 5, 2022));
        emp10.addSalary(new Salary(1006, 33000, 6, 2022));
        emp10.addSalary(new Salary(1007, 34000, 7, 2022));
        emp10.addSalary(new Salary(1008, 35000, 8, 2022));
        emp10.addSalary(new Salary(1009, 36000, 9, 2022));
        emp10.addSalary(new Salary(1010, 37000, 10, 2022));
        emp10.addSalary(new Salary(1011, 38000, 11, 2022));
        emp10.addSalary(new Salary(1012, 39000, 12, 2022));


//        Employee Added to List
        List<Employee> employees = new ArrayList<>(List.of(emp1, emp2, emp3, emp4, emp5, emp6, emp7, emp8, emp9, emp10));

//        ----------------------------------------------------------------------------------
//        ----------------------------------------------------------------------------------
//        ----------------------------------------------------------------------------------


//  Question 1:  In the last 6 months calculate the total sum of salaries given by each company. -----------
        System.out.println("Sum of Salary by Company :" +sumSal(employees));

//  Question 2:  Each month top salary of the employees. -----------
        //System.out.println("Highest Salary by Month: "+getHighSalPerMonth(employees));

//  Question 3: Month wise percentage growth of salaries for each employee(can use employee name or id).  -----------
        //System.out.println("Salary List: "+increaseSalaryByPercentage(employees, 3));

//  Question 4:  Make a list of all the employees in this format. [id1_emp1_sumOfSalariesOfEmp_CompanyName1,id2_emp2_sumOfSalariesOfEmp_CompanyName2]---
        //System.out.println(employees);

//    Question 5: Now make a company wise map which shows the max salary given by the company each month.
        //System.out.println("Highest Salary by Month and Company: "+getHighSalPerMonthByCompany(employees));



    }




    public static Map<String, Double> sumSal(List<Employee> employees){
        Map<String, Double> sumSal= new HashMap<>();
        for(Employee e : employees){
            Double sal = e.getSalaries().stream().skip(Math.max(0, e.getSalaries().size() - 6)).map(Salary::getSalary).reduce(0.0,Double::sum);
            if(sumSal.containsKey(e.getCompany())){
                sumSal.put(e.getCompany(), sumSal.get(e.getCompany())+sal);
            }
            else{
                sumSal.put(e.getCompany(), sal);
            }
        }
        return sumSal;
    }

    public static Map<Integer,Double> getHighSalPerMonth(List<Employee> employees){
        Map<Integer, Double> sal = new HashMap<>();
        for (int i = 0; i < employees.get(0).getSalaries().size(); i++) {
            double high = 0;
            for(Employee e : employees){
                double salary;
                try {
                     salary = e.getSalaries().get(i).getSalary();
//                    System.out.println(salary);
                }
                catch (Exception ex){
                    salary = 0;
                }
                high = Math.max(high, salary);
            }
            sal.put(i+1, high);
        }
        return sal;
    }
    public static Map<String, Double> getHighSalPerMonthByCompany(List<Employee> employees){
        Map<String, Double> sal = new HashMap<>();
        for (int i = 0; i <= 11; i++) {
            double high = 0;
            String name = "";
            for(Employee e : employees){
                double salary;

                try {
                    salary = e.getSalaries().get(i).getSalary();
//                    System.out.println(salary);
                }
                catch (Exception ex){
                    salary = 0;
                }
                if(high<salary){
                    high = salary;
                    name = e.getCompany();
                }
            }

            sal.put(name+" Month: "+(i+1), high);
        }
        return sal;

        }

    public static List<List<Salary>> increaseSalaryByPercentage(List<Employee> employees, double growth){
        for(Employee e : employees){
            for(Salary s : e.getSalaries()){
                s.setSalary(growth);
            }
        }

    return employees.stream().map(Employee::getSalaries).collect(Collectors.toList());
    }

}

