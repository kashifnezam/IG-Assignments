import java.util.List;


public class Main {
    public static void main(String[] args) {
        // Sample products
        Product laptop = new Product("Laptop", 999.99);
        Product smartphone = new Product("Smartphone", 499.99);

        //shopping cart
        ShoppingCart cart = new ShoppingCart(List.of(laptop, smartphone));
        PaymentMethod.listOfProduct(cart.totalProduct());
        // checkout process
        double totalAmount = cart.calculateTotal();
        System.out.println("Total amount: ₹" + totalAmount);

        // Creating payment with credit card
        System.out.println("Paying with credit card:");
        PaymentMethod.createCreditCardPayment("1234567890123456").pay(totalAmount);

        // Creating payment with cash
        System.out.println("Paying with cash:");
        PaymentMethod.createCashPayment().pay(totalAmount);

        // Order id
        PaymentMethod.createCashPayment().order();


    }
}
