import java.util.List;
import java.util.stream.Collectors;

// shopping cart class
class ShoppingCart {
    private final List<Product> items;

    public ShoppingCart(List<Product> items) {
        this.items = items;
    }

    public double calculateTotal() {
        return items.stream().mapToDouble(Product::getPrice).sum();
    }

    public List<String> totalProduct(){
        return items.stream().map(Product::getName).collect(Collectors.toList());
    }


}