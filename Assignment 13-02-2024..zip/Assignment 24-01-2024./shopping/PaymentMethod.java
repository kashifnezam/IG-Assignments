import java.util.List;

interface PaymentMethod {
    void pay(double amount);

    // Static method to create a credit card payment
    static PaymentMethod createCreditCardPayment(String cardNumber) {
        return amount -> System.out.println("Paid ₹" + amount + " using credit card ending with: " + cardNumber);
    }

    // Static method to create a cash payment
    static PaymentMethod createCashPayment() {
        return amount -> System.out.println("Paid ₹" + amount + " in cash.");
    }

    static void listOfProduct(List<String> product){
        System.out.println("Your overall product: "+product);
    }
    default void order() {
        System.out.println("Your order id : KMNo"+(int)Math.floor(Math.random()*10000));
    }
}